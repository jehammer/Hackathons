# Hackathons

## Warning: This code is depreciated, unstable, and with incomplete sections.
A storage place for all the code done at Hackathons, either alone or with friends. 

Credit where it is due (aside from myself):
     
Cntrlr

     FourteenFourHundredStudios:(https://github.com/FourteenFourHundredStudios)
 
     imkimchi:(https://github.com/imkimchi)
 
     Diamondrubix: (https://github.com/Diamondrubix)
     
Gradient
      
      Diamondrubix: (https://github.com/Diamondrubix)
      
      kyleOckerlund: (https://github.com/kyleOckerlund)
