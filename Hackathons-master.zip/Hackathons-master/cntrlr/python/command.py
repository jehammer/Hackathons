import sys

print "hi"
print sys.argv[1]