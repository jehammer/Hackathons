export default {
    LOCALHOST_URI: "http://localhost:3000/eroapi",
    MONGODB_URI: "mongodb://localhost/cntlr"
}