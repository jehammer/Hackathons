<template>
  <div class="item">
    <div class="content">
      <i class="icon remove right-float"></i>
      <a class="header"></a>
      <div class="description">
        <a class="ui tiny label right-float">ff</a>
      </div>
    </div>
  </div>
</template>