<template lang="pug">
.eleven.wide.column.ho
    h1 sex
</template>

<style>
.ho {
    background-color: #D4D9DA;
}
</style>